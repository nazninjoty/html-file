
let Arr = [2, 4, 55, 35, 6, 54,33, 87, 98, 87, 65];
let oddValue = [];

    let k = 0;
    for(let i = 0 ; i< Arr.length; i++){
        if (Arr[i] % 2 != 0){
          oddValue[k] = Arr[i];
          k++
        }    
    }
    document.write( 'TASK 4: The odd values are = ' + oddValue+ '<br><br>');
    console.log(oddValue);
