let oddArr = [2,4,6, 54, 87, 98, 23, 65, 59];
let oddIndex = [];
    let j = 0;
    for(let i = 0 ; i< oddArr.length; i++){
        if (i%2 != 0){
          oddIndex[j] = i;
          j++
        }    
    }
    document.write( 'TASK 3:The odd indexes are = ' + oddIndex + '<br><br>');
    console.log(oddIndex);
