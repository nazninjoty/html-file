let mystring = "Hello! this is shohan.Android Developer.....";
var myString2 = "Keep Learning !"

// 1nmbr function
document.write('TASK 1 :<br><b>1.To LowerCase Function - </b>',mystring.toLowerCase() , '<br><br>');
console.log(mystring.toLowerCase());

// 2nmbr function
document.write('<b>2.To UpperCase Function - </b>',mystring.toUpperCase() , '<br><br>');
console.log(mystring.toUpperCase());

// 3nmbr function
document.write('<b>3.Length - </b> The length of string is = ', mystring.length, '<br><br>');
console.log('The length of string is - ',mystring.length);

// 4nmbr function
document.write('<b>4.SubString Function - </b>The substring of my string is = ', mystring.substring(6,22), '<br><br>');
console.log('The substring of my string is = ', mystring.substring(6,21));

// 5nmbr function
document.write('<b>5.Search function - </b> Searching position of shohan into my string = ', mystring.search('shohan'), '<br><br>');
console.log('Searching position of shohan into my string = ', mystring.search('shohan'));

// 6nmbr function
document.write('<b>6.Match function - </b> Searching shohan into my string = ', mystring.match(/shohan/g), '<br><br>');
console.log('Searching shohan into my string = ', mystring.search(/shohan/g));

// 7nmbr function
document.write('<b>7.Replace function - </b> Replacing hello with welcome = ', mystring.replace("Hello", "Welcome"), '<br><br>');
console.log('Replace function - Replacing hello with welcome = ', mystring.replace("Hello", "Welcome"));

// 8nmbr function
document.write('<b>8.ConCat function - </b> Concating 2 strings = ', mystring.concat(myString2), '<br><br>');
console.log('ConCat function - RConcating 2 strings = ', mystring.concat(myString2));



