
var num1 = 10;
var num2 = 20;
var string1 = '1256', string2 = '500';



    let total = Number(string1) + Number(string2);
    document.write('TASK 5 :The Addition of the strings = '+ total + '<br><br>');
    console.log(total);

